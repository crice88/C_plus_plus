//============================================================================
// Name        : lab10.cpp
// Author      : Colin Rice
// Version     :
// Copyright   : Your copyright notice
// Description : Lab 10 Containers
//============================================================================

#include <iostream>
#include <sstream>
#include "Line.h"
#include "Point.h"

using namespace std;

int main()
{
	Line l;
	Point p(4,5);
	l.addBack(p);

	cout << "hey" << endl;
	return 0;
}
