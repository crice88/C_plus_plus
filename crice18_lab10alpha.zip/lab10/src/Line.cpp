/*
 * Line.cpp
 *
 *  Created on: Nov 1, 2014
 *      Author: williamhooper
 */

#include "Line.h"
#include "Point.h"

/**
 * Default Line constructor
 */
Line::Line()
{
	Point* p1 = new Point;
	iterator = 1;
	howfull = 0;
	this->p[0] = *p1;
}

void Line::addBack(Point a)
{
	if(this->howfull == this->iterator )
	{
		Point p1[iterator + 20];
		for(int i = 0; i < this->howfull; i++)
		{
			p1[i] = this->p[i];
		}
	}
	else
	{

	}
}

unsigned int Line::size() const
{
	return howfull;
}
/**
 * Line deconstructor
 */
Line::~Line()
{

}

