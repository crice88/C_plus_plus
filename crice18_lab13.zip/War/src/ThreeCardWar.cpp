//============================================================================
// Name        : ThreeCardWar.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>
#include <vector>

#include "Deck.h"
#include "Card.h"
#include "TerminalPlayer.h"
#include "Player.h"
#include "AIPlayer.h"

using namespace std;

int main()
{
	// Game loop
	Deck gameDeck;	// Instantiates both players and the deck
	TerminalPlayer player;
	AIPlayer compPlayer;
	bool compFirst = false;
	bool playerFirst = false;
	gameDeck.shuffle();	// Shuffle the deck
	int randJoker = (rand() % 100);	// Randomly generates a number 0-99, if less than 50, player goes first

	for(int i = 0; i < 3; i++)	// Draw three cards each
	{
		player.receiveCard(gameDeck.draw());
		compPlayer.receiveCard(gameDeck.draw());
	}

	if(randJoker < 50)	// Checks who is going first
	{
		Card joker = Card::getJoker();
		Card playerCard = player.playCard(joker);	// Passes the joker to the player
		Card computerCard = compPlayer.playCard(playerCard);
		if(playerCard < computerCard)	// Tests for inequality
		{
			std::cout << "Computer player wins the round :(" << std::endl;
			compPlayer.addScore(2);	// Adds score to who wins
			compFirst = true;	// Sets who won flag to tell who is going first next round
			playerFirst = false;
			player.receiveCard(gameDeck.draw());	// Draws a card for each player
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		else if(computerCard < playerCard)
		{
			std::cout << "You win this round!!" << std::endl;
			player.addScore(2);
			playerFirst = true;
			compFirst = false;
			player.receiveCard(gameDeck.draw());
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		else if(playerCard == computerCard)	// Test for equality, if equal, player goes first
		{
			std::cout << "Draw!!" << std::endl;
			playerFirst = true;
			compFirst = false;
			player.receiveCard(gameDeck.draw());
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		std::cout << "The score is ";
		cout << "Computer Player:" << compPlayer.getScore();
		cout << " Human Player:" << player.getScore() << endl;
	}
	else	// if randJoker > 50
	{
		Card joker = Card::getJoker();
		Card computerCard = compPlayer.playCard(joker);
		Card playerCard = player.playCard(playerCard);
		if(playerCard < computerCard)
		{
			std::cout << "Computer player wins the round :(" << std::endl;
			compPlayer.addScore(2);
			compFirst = true;
			playerFirst = false;
			player.receiveCard(gameDeck.draw());
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		else if(computerCard < playerCard)
		{
			std::cout << "You win this round!!" << std::endl;
			player.addScore(2);
			playerFirst = true;
			compFirst = false;
			player.receiveCard(gameDeck.draw());
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		else if(playerCard == computerCard)
		{
			std::cout << "Draw!!" << std::endl;
			playerFirst = false;
			compFirst = true;
			player.receiveCard(gameDeck.draw());
			compPlayer.receiveCard(gameDeck.draw());
			compPlayer.cardsPlayed(playerCard, computerCard);
		}
		std::cout << "The score is ";
		cout << "Computer Player:" << compPlayer.getScore();
		cout << " Human Player:" << player.getScore() << endl;
	}

	while(gameDeck.isEmpty() != true)	// While the deck still has cards in it
	{
		if (compFirst == true)	// If computer won the last round, go first
		{
			Card joker = Card::getJoker();
			Card computerCard = compPlayer.playCard(joker);
			Card playerCard = player.playCard(computerCard);
			if(playerCard < computerCard)
			{
				std::cout << "Computer player wins the round :(" << std::endl;
				compPlayer.addScore(2);
				compFirst = true;
				playerFirst = false;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(computerCard < playerCard)
			{
				std::cout << "You win this round!!" << std::endl;
				player.addScore(2);
				playerFirst = true;
				compFirst = false;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(playerCard == computerCard)
			{
				std::cout << "Draw!!" << std::endl;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
		}
		else if (playerFirst == true)	// If the player won the last round
		{
			Card joker = Card::getJoker();
			Card playerCard = player.playCard(joker);
			Card computerCard = compPlayer.playCard(playerCard);
			if(playerCard < computerCard)
			{
				std::cout << "Computer player wins the round :(" << std::endl;
				compPlayer.addScore(2);
				compFirst = true;
				playerFirst = false;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(computerCard < playerCard)
			{
				std::cout << "You win this round!!" << std::endl;
				player.addScore(2);
				playerFirst = true;
				compFirst = false;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(playerCard == computerCard)
			{
				std::cout << "Draw!!" << std::endl;
				player.receiveCard(gameDeck.draw());
				compPlayer.receiveCard(gameDeck.draw());
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
		}
		std::cout << "The score is ";
		cout << "Computer Player:" << compPlayer.getScore();
		cout << " Human Player:" << player.getScore() << endl;
	}

	while((gameDeck.isEmpty() == true) && (player.hasCards() == true))	// While the deck is empty but cards in hand are still available
	{
		if (playerFirst == true)
		{
			Card joker = Card::getJoker();
			Card playerCard = player.playCard(joker);
			Card computerCard = compPlayer.playCard(playerCard);
			if(playerCard < computerCard)	// No card is drawn, if one was, game would error
			{
				std::cout << "Computer player wins the round :(" << std::endl;
				compPlayer.addScore(2);
				compFirst = true;
				playerFirst = false;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(computerCard < playerCard)
			{
				std::cout << "You win this round!!" << std::endl;
				player.addScore(2);
				playerFirst = true;
				compFirst = false;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(playerCard == computerCard)
			{
				std::cout << "Draw!!" << std::endl;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
		}
		else if (compFirst == true)
		{
			Card joker = Card::getJoker();
			Card computerCard = compPlayer.playCard(joker);
			Card playerCard = player.playCard(computerCard);
			if(playerCard < computerCard)
			{
				std::cout << "Computer player wins the round :(" << std::endl;
				compPlayer.addScore(2);
				compFirst = true;
				playerFirst = false;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(computerCard < playerCard)
			{
				std::cout << "You win this round!!" << std::endl;
				player.addScore(2);
				playerFirst = true;
				compFirst = false;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
			else if(playerCard == computerCard)
			{
				std::cout << "Draw!!" << std::endl;
				compPlayer.cardsPlayed(playerCard, computerCard);
			}
		}
		std::cout << "The score is ";
		cout << "Computer Player:" << compPlayer.getScore();
		cout << " Human Player:" << player.getScore() << endl;
	}

	if((gameDeck.isEmpty() == true ) && (player.hasCards() == false))	// When the deck and hands are empty, game is over
	{
		cout << "Final Score is ";	// Displays final score
		cout << "Computer Player:" << compPlayer.getScore();
		cout << " Human Player:" << player.getScore() << endl;
	}

	if(compPlayer.getScore() < player.getScore())	// Announce who won
	{
		cout << "YOU WIN!!! YAY!!!";
	}
	else
	{
		cout << "The computer has bested you, better luck next time...";
	}
	// End game loop

/*
	// Testing purposes
	Deck d;
	Deck d1;
	d.shuffle();
	Card c = d.draw();
	Card c1(Card::Spades, Card::Four);
	Card c2(Card::Hearts, Card::King);
	Card c3(Card::Spades, Card::Four);
	Card c4 = Card::getJoker();
	Card c5 = d1.draw();
	Card c6 = d1.draw();
	Card c7 = d1.draw();
	Card c8(Card::Spades, Card::Four);
	Card c9(Card::Hearts, Card::King);
	Card c10(Card::Spades, Card::Four);
	Card c11 = Card::getJoker();
	TerminalPlayer t;
	TerminalPlayer t1;

	// Testing Deck and Card class
	cout << (c1 == c3) << endl;	// Testing equality operator
	cout << (c1 == c2) << endl;
	cout << (c1 < c2) << endl;	// Testing less than operator
	cout << (c2 < c1) << endl;
	cout << (d.isEmpty()) << endl;	// Testing the isEmpty function
	cout << c4 << endl;	// Testing getJoker()
	cout << c3 << endl;	// Testing basic constructor functionality
	cout << c2 << endl;
	cout << c4.isJoker() << endl;	// Testing isJoker()
	cout << c << endl;	// Testing shuffle()
	cout << c5 << endl;	// Testing draw() and to make sure the elements are created in correct order
	cout << c6 << endl;
	cout << c7 << endl;

	// Testing playCard() functionality
	t.playCard(c11);	// Passed a joker card, test rest of functionality of method
	t1.playCard(c10);	// Passes generic card
*/

	return 0;
}
