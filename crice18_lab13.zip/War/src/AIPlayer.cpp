/*
 * AIPlayer.cpp
 *
 *  Created on: May 10, 2015
 *      Author: student
 */

#include "AIPlayer.h"
#include "Player.h"
#include "Deck.h"

AIPlayer::AIPlayer()
{
	// TODO Auto-generated constructor stub
}

const Card AIPlayer::playCard(const Card playerCard)
{
	if(playerCard.isJoker())	// Check who has the special joker card
	{
		std::cout << "It is the computers turn" << std::endl;
	}

	int cardIndex = rand() % 3;
	Card c = hand[cardIndex];
	std::cout << "The computer has played a " << c << std::endl;
	hand.erase(hand.begin() + cardIndex);	// Erases the card from the hand

	return c;
}
AIPlayer::~AIPlayer() {
	// TODO Auto-generated destructor stub
}

