#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>

using namespace std;

double square( double y ) // Square variable function
{
    return y*y;
}

void error(string s)    // Basic error detection
{
    throw runtime_error( s );
}

int main()
{
    double mean = 0.0;
    double sum = 0.0;
    double std_dev = 0.0;
    double std_dev_final = 0.0;
    int v_size = 0;
    
    // Get total number of values
    cout << "Please Enter the Number of Values to be Calculated: ";
    cin >> v_size;
    if (!cin) error("Bad Input!");
    
    vector<double> values(v_size);  // Sets the size of the vector to the number of values needed for calculation
    
    // Take the values from the user   
    for ( int i = 0; i < values.size(); i++ )
    {
        cout << "Please Enter the Values: ";
        cin >> values[i];
        if (!cin) error("Bad Input!");
    }
    
    // Calculate the Mean
    for( int i = 0; i < values.size(); i++ )
    {
        sum += values[i];
    }
       
    mean = (sum / values.size());
    cout << "The Mean is: " << mean << endl;
    
    // Calculate the Standard Deviation
    for( int i = 0; i < values.size(); i++ )
    {
        std_dev += square( (values[i] - mean) ); // Sum of all (X-M)^2
    }
         
    std_dev_final = sqrt( std_dev / (values.size() - 1) ); // Take the sum and divide by N-1 and take the root
    cout << "The Standard Deviation is: " << std_dev_final << endl;
    
    return 0;
}
