/*
 * Data.h
 *
 *  Created on: April 5, 2015
 *      Author: Colin Rice
 */
#include <iostream>
#include <fstream>
#include <string>

#ifndef DATA_H_
#define DATA_H_

using namespace std;

class Data
{
public:
	// Constructors
	Data(string s);
	Data();

	// Overloaded operators
	friend bool operator==(Data dlh, Data drh);
	friend ostream& operator <<(std::ostream&, const Data&);
	friend bool operator <(const Data& lhs,const Data& rhs);

	// Getters
	const string getIndex();
	const string getFName();
	const string getLName();
	const string getAddress();
	const string getCity();
	const string getState();
	const string getZip();

	// Setters
	void setIndex(string x);
	void setFName(const string s);
	void setLName(const string s);
	void setAddress(const string s);
	void setCity(const string s);
	void setState(const string s);
	void setZip(const string s);

	// Destructor
	virtual ~Data();
private:
	// Fields
	string index;
	string fname;
	string lname;
	string address;
	string city;
	string state;
	string zip;
};

#endif /* DATA_H_ */
