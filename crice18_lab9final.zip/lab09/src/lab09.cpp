//============================================================================
// Name        : lab09.cpp
// Author      : Colin Rice
// Version     :
// Copyright   : Your copyright notice
// Description : Lab 9 Outputting Data
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include "Data.h"

using namespace std;

bool fNameSort (Data lhs, Data rhs)	// Sort by first name ('<' has been overloaded for sort of lname)
{
	if(lhs.getFName() == rhs.getFName())	// Check for first name equality, if true, sort by last name
	{
		return(lhs.getLName() < rhs.getLName());
	}
	else
	{
		return (lhs.getFName() < rhs.getFName());
	}
}

string center(const string s, const int w)	// Code segment researched at http://stackoverflow.com/questions/14765155/
											// how-can-i-easily-format-my-data-table-in-c
{
    stringstream ss, spaces;
    int padding = w - s.size();                 // count excess room to pad
    for(int i=0; i<padding/2; ++i)
        spaces << " ";
    ss << spaces.str() << s << spaces.str();    // format with padding
    if(padding>0 && padding%2!=0)               // if odd #, add 1 space
        ss << " ";
    return ss.str();
}

string left(const string s, const int w)	// Code segment researched at http://stackoverflow.com/questions/14765155/
											// how-can-i-easily-format-my-data-table-in-c
{
    stringstream ss, spaces;
    int padding = w - s.size();                 // count excess room to pad
    for(int i=0; i<padding; ++i)
        spaces << " ";
    ss << s << spaces.str();                    // format with padding
    return ss.str();
}

int main()
{
	string data;
	string modFileName;
	stringstream modfilepath;
	int iterator = 0;
	unsigned int x = 0;
	vector<Data> d;
	vector<string> map;

	cout << "Please enter the file name: ";	// Prompt user for directory and file name
	string fileName;
	cin >> fileName;
	cout << endl << endl;	// Added whitespace for better readability
	ifstream inFile(fileName);	// Opens file stream
	istringstream ss(fileName);

	//ifstream inFile("/home/student/Dropbox/C++/resources/database.csv");	// For testing purposes only
	//ofstream outFile("/home/student/Dropbox/C++/resources/hey.txt");	// For testing purposes only

	if(inFile.is_open())	// Credit to Professor Hooper
	{
		while (true)
		{
			getline(inFile, data);
			if ( inFile.eof() )
			{
				break;
			}
			d.push_back(Data(data));
		}
	}
	else
	{
		cerr << "Could not open file " << endl;
		return 1;
	}

	while( x < d.size() )	// Check for duplicates in the file
	{
		unsigned int y = 0;
		while(y < d.size())
		{
			if(y == x)
			{
				y++;
			}
			if(d[x] == d[y])
			{
				d.erase(d.begin()+x);
			}
			y++;
		}
		x++;
	}

	sort(d.begin(), d.end());	// Sort using overridden '<' comparison
	sort(d.begin(), d.end(), fNameSort);	// Sort fname using a function call

	for(unsigned int i = 0; i < d.size(); i++)	// Changes index to account for duplicates that have been deleted, re number
	{
		stringstream ss;
		ss << (i + 1);
		d[i].setIndex(ss.str());
	}

	// Outputs header, center justified
	cout << center("First Name", 16) << center("Last Name", 14) << center("Address", 26) << center("City", 20)
		<< center("State", 14) << center("Zip", 10) << endl;

	cout << string(100, '-') << endl;

	for(unsigned int i = 0; i < d.size(); i++)
	{
		if(d[i].getFName().size() > 16 )	// Check to see if each field will fit spreadsheet, if not, resize
		{
			string str = d[i].getFName();
			str.resize(16);
			d[i].setFName(str);
		}

		if(d[i].getLName().size() > 16 )
		{
			string str = d[i].getLName();
			str.resize(16);
			d[i].setLName(str);
		}

		if(d[i].getAddress().size() > 26 )
		{
			string str = d[i].getAddress();
			str.resize(26);
			d[i].setAddress(str);
		}

		if(d[i].getCity().size() > 20 )
		{
			string str = d[i].getCity();
			str.resize(20);
			d[i].setCity(str);
		}

		if(d[i].getState().size() > 14 )
		{
			string str = d[i].getState();
			str.resize(14);
			d[i].setState(str);
		}

		if(d[i].getZip().size() > 10 )
		{
			string str = d[i].getZip();
			str.resize(10);
			d[i].setZip(str);
		}

		// Outputs each field, left justified
		cout << left(d[i].getFName(), 16) << left(d[i].getLName(), 16) << left(d[i].getAddress(), 26)
		<< left(d[i].getCity(), 20) << left(d[i].getState(), 14) << left(d[i].getZip(), 10) << endl;
	}

	while(getline(ss, modFileName, '/'))	// Parse string by / char, place each piece in array
	{
		map.push_back(modFileName);
		iterator++;
	}

	modFileName = map[map.size() - 1];	// Assign last index of array to new file name

	for(unsigned int i = 0; i < (map.size() - 1) ; i++)
	{
		modfilepath << map[i] << "/";
	}

	ofstream outFile(modfilepath.str() + "./new_" + modFileName); // Opens output file stream and
																  // saves to current directory

	if(!outFile.is_open())	// If the output file fails, error
	{
		cerr << "Can't output a file...";
		return 1;
	}

	if(outFile.is_open())	// Is the file open?
	{
		for(unsigned int i = 0; i < d.size(); i++)	// Puts all data into output file
		{
			outFile << d[i];
		}
		outFile.close();
	}

	//	Testing

/*	cout << "Testing formatted data: " << endl;	// Testing to make sure output to file is correct

	for(unsigned int i = 0; i < d.size(); i++)
	{
		cout << d[i];
	}

	cout << "Testing getters and setters: " << endl;	// Testing getters and setters
	cout << "Original Values are as follows: " << endl;

	cout << d[15].getIndex() << endl;
	cout << d[15].getFName() << endl;
	cout << d[15].getLName() << endl;
	cout << d[15].getAddress() << endl;
	cout << d[15].getCity() << endl;
	cout << d[15].getState() << endl;
	cout << d[15].getZip() << endl;

	cout << "Modified values are as follows: " << endl;	// Modify the values and return them using get and set

	d[15].setIndex("4");
	cout << d[15].getIndex() << endl;
	d[15].setFName("Fred");
	cout << d[15].getFName() << endl;
	d[15].setLName("Blackburn");
	cout << d[15].getLName() << endl;
	d[15].setAddress("777 Caber Dr.");
	cout << d[15].getAddress() << endl;
	d[15].setCity("Lincoln");
	cout << d[15].getCity() << endl;
	d[15].setState("CA");
	cout << d[15].getState() << endl;
	d[15].setZip("95648");
	cout << d[15].getZip() << endl;

	cout << "Testing output data: " << endl;	// Testing modded file name

	cout << modFileName << endl;*/

	return 0;
}
