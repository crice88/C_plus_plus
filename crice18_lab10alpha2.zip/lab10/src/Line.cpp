/*
 * Line.cpp
 *
 *  Created on: Nov 1, 2014
 *      Author: williamhooper
 */

#include "Line.h"
#include "Point.h"
#include <cmath>

/**
 * Default Line constructor
 */
Line::Line()	// Default constructor, sets initial array size to 10 and assigns pointer to it
{
	arraySize = 10;
	elementSize = 0;
	pointArray = new Point[arraySize];
}

void Line::addBack(Point a)	// Adds a point to the back of the array
{
	if(elementSize == arraySize)	// If array is too small copy all data to a new array, reassign pointer
	{
		Point tempArray[arraySize + 10];
		for(int i = 0; i < arraySize; i++)
		{
			tempArray[i] = pointArray[i];
		}
		pointArray = tempArray;
		pointArray[elementSize++] = a;
		arraySize = (10 + arraySize);
	}
	else
	{
		pointArray[elementSize++] = a;
	}
}

unsigned int Line::size() const	// Returns how many elements in the array (not total size)
{
	return elementSize;
}

int Line::length() const	// Takes the final x, y (last element in array) and initial x,y (first element
							// in the array) and calculates the distance between them.
{
	int xf, xi, yf, yi, d;
	xf = pointArray[elementSize].getX();
	xi = pointArray[0].getX();
	yf = pointArray[elementSize].getY();
	yi = pointArray[0].getY();
	d = sqrt(((xf - xi)*(xf - xi)) + ((yf - yi)*(yf - yi)));
	return d;
}

void Line::clear()	// Deletes the pointer, reassigns it to a new array
{
	delete[] pointArray;
	arraySize = 10;
	elementSize = 0;
	pointArray = new Point[arraySize];
}

Point& Line::operator [](int index)	// Overloaded [], returns the point at user selected index
{
	return pointArray[index];
}
/**
 * Line deconstructor
 */
Line::~Line()
{

}

