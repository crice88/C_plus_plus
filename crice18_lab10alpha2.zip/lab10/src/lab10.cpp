//============================================================================
// Name        : lab10.cpp
// Author      : Colin Rice
// Version     :
// Copyright   : Your copyright notice
// Description : Lab 10 Containers
//============================================================================

#include <iostream>
#include <sstream>
#include "Line.h"
#include "Point.h"

using namespace std;

int main()
{
	// Testing
	Line l;
	Line l1;
	Point p(1, 3);
	Point p1(4, 5);
	Point p2(1, 3);
	Point p3(1, 3);
	Point p4(1, 3);
	Point p5(1, 3);
	Point p6(1, 3);
	Point p7(1, 3);
	Point p8(1, 3);
	Point p9(1, 3);
	Point p10(1, 3);
	Point p11(1, 3);
	Point p12(16, 4);
	Point p13(12,13);

	l.addBack(p);	// Testing size and length
	l.addBack(p1);
	cout << l.size() << endl;
	cout << l.length() << endl;

	l.addBack(p2);	// Testing "if" condition, extending original array
	l.addBack(p3);
	l.addBack(p4);
	l.addBack(p5);
	l.addBack(p6);
	l.addBack(p7);
	l.addBack(p8);
	l.addBack(p9);
	l.addBack(p10);
	l.addBack(p11);
	cout << l.size() << endl;

	l.clear();	// Testing clear method
	l.addBack(p12);
	l.addBack(p13);
	cout << l.size() << endl;

	return 0;
}
