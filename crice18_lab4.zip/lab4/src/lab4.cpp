//============================================================================
// Name        : lab4.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdexcept>
#include <iostream>
#include "Time.h"

using namespace std;

int main()
{
	Time t(13, 45, 52, 125);
	Time t1;
	Time t2(14457600);

	cout << t.asLong() << endl;
	cout <<  t.is24Hour()<< endl;
	t.set24Hour(false);
	cout << t.toString() << endl;

	cout << t1.asLong() << endl;
	cout <<  t1.is24Hour()<< endl;
	t1.set24Hour(false);
	cout << t1.toString() << endl;

	cout << t2.asLong() << endl;
	cout <<  t2.is24Hour()<< endl;
	t2.set24Hour(false);
	cout << t2.toString() << endl;

	return 0;
}
