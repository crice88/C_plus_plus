/*
 * TerminalPlayer.cpp
 *
 *  Created on: May 4, 2015
 *      Author: student
 */

#include "TerminalPlayer.h"
#include "Player.h"
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

TerminalPlayer::TerminalPlayer()
{
	// TODO Auto-generated constructor stub

}

const Card playCard(const Card opponentCard)
{
	if(opponentCard.isJoker())
	{
		std::cout << "Computer is going first" << std::endl;
	}
	else
	{
		std::cout << opponentCard << std::endl;
	}
	for(int i = 0; i < hand.size(); i++)
	{
		std::cout << hand[i] << std::endl;
	}
	return opponentCard;
}

TerminalPlayer::~TerminalPlayer()
{
	// TODO Auto-generated destructor stub
}

