// Colin Rice
// Professor Hooper
// CS 66
// Lab 3
// 2-09-2014

#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>

using namespace std;

float square( float y ) // Square variable function
{
    return y*y;
}

float average( vector<float> values )   // Calculates the average of a set of numbers
{
    float sum;
    float average;
    
    for( int i = 0; i < values.size(); i++ )
    {
        sum += values[i];   // Sums all values
    }
       
    average = (sum / values.size());    // Sum divided by N
    return average;
}

float stddeviation( vector<float> values )  // Calculates the Standard Deviation of a set of numbers
{
    float sumof;
    float stddeviation;
    
    for( int i = 0; i < values.size(); i++ )
    {
        sumof += square( (values[i] - average(values) ) ); // Sum of all (X-M)^2
    }
         
    stddeviation = sqrt( sumof / (values.size() - 1) );
    return stddeviation;
}
    
int main()
{
    int v_size;
    
    // Get total number of values
    cout << "Please Enter the Number of Values to be Calculated: ";
    cin >> v_size;
    while ( v_size <= 0 )    // While v_size is negative, error and prompt for a proper input
    {
        cout << "ERROR; Please enter a positive integer greater than zero: ";
        cin.clear();
        cin.ignore();
        cin >> v_size;
    }
    cin.clear();
    
    vector<float> values(v_size);  // Sets the size of the vector to the number of values needed for calculation
    
    // Take the values from the user   
    for ( int i = 0; i < values.size(); i++ )
    {
        cout << "Please enter value number " << ( i + 1 )<< ": ";
        cin >> values[i];
        while(!cin) // While values[i] is not a float, error and prompt for a proper input
        {
            cout << "ERROR; Please enter a float: ";
            cin.clear();
            cin.ignore();
            cin >> values[i];
        }     
    }
    
    cout << "The Mean is: " << average( values ) << endl;   // Outputs the Mean to console
    
    cout << "The Standard Deviation is: " << stddeviation( values ) << endl;    // Outputs the Standard Deviation to console
    
    return 0;
}


