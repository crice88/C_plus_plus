/*
 * Data.cpp
 *
 *  Created on: April 5, 2015
 *      Author: Colin Rice
 */

#include "Data.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

// Getters
const string Data::getIndex()
{
	return index;
}
const string Data::getFName()
{
	return fname;
}
const string Data::getLName()
{
	return lname;
}
const string Data::getAddress()
{
	return address;
}
const string Data::getCity()
{
	return city;
}
const string Data::getState()
{
	return state;
}
const string Data::getZip()
{
	return zip;
}

// Setters
void Data::setIndex(string s)
{
	index = s;
}

void Data::setFName(const string s)
{
	fname = s;
}
void Data::setLName(const string s)
{
	lname = s;
}

void Data::setAddress(const string s)
{
	address = s;
}

void Data::setCity(const string s)
{
	city = s;
}

void Data::setState(const string s)
{
	state = s;
}

void Data::setZip(const string s)
{
	zip = s;
}

Data::Data()	// Default constructor
{
	index = "";
	fname = "";
	lname = "";
	address = "";
	city = "";
	state = "";
	zip = "";
}

Data::Data(string s)	// Requires string
{
	stringstream ss(s);

	getline(ss, index, ',');	// Extract values and store them in appropriate objects
	getline(ss, fname, ',');
	getline(ss, lname, ',');
	getline(ss, address, ',');
	getline(ss, city, ',');
	getline(ss, state, ',');
	getline(ss, zip, ',');

}

bool operator <(const Data& lhs, const Data& rhs)	// Check to see if strings are less than (Overrides <)
{
	return (lhs.lname < rhs.lname);
}

bool operator==(const Data dlh, const Data drh)	// Check for equality (Overrides ==)
{
	if( (dlh.index == drh.index) || ((dlh.fname == drh.fname) && (dlh.lname == drh.lname) && (dlh.address == drh.address) &&
		(dlh.city == drh.city)	&& (dlh.state == drh.state) && (dlh.zip == drh.zip)))
		return true;
	else
		return false;
}

ostream& operator <<(std::ostream& ss, const Data& d)	// Outputs formatted data (Overrides <<)
{
	//ss << "Index: " << d.index << " First Name: " << d.fname << " Last Name: " << d.lname << endl << "Address: " << d.address
	   //<< " City: " << d.city << " State: " << d.state << " Zip: " << d.zip << endl;
	ss << d.index << "," << d.fname << "," << d.lname << "," << d.address << "," <<
			d.city << "," << d.state << "," << d.zip << endl;

	return ss;
}

Data::~Data()
{
	// TODO Auto-generated destructor stub
}

