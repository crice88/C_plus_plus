//============================================================================
// Name        : lab8.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include "Data.h"

using namespace std;

int main()
{
	string data;
	string modFileName;
	int iterator = 0;
	unsigned int x = 0;
	vector<Data> d;
	vector<string> map;

	cout << "Please enter the file name: ";	// Prompt user for directory and file name
	string fileName;
	cin >> fileName;
	ifstream inFile(fileName);	// Opens file stream
	istringstream ss(fileName);

	//ifstream inFile("/home/student/Dropbox/C++/resources/database.csv");	// For testing purposes only
	//ofstream outFile("/home/student/Dropbox/C++/resources/hey.txt");	// For testing purposes only

	while(getline(ss, modFileName, '/'))	// Parse string by / char, place each piece in array
	{
		map.push_back(modFileName);
		cout << map[iterator];
		iterator++;
	}

	modFileName = map[map.size() - 1];	// Assign last index of array to new file name

	ofstream outFile("./new_" + modFileName);	// Opens output file stream and saves to current directory

	if(!outFile.is_open())	// If the output file fails, error
	{
		cerr << "Can't output a file...";
		return 1;
	}

	if(inFile.is_open())	// Credit to Professor Hooper
	{
		while (true)
		{
			getline(inFile, data);
			if ( inFile.eof() )
			{
				break;
			}
			cout << data << endl;
			d.push_back(Data(data));
		}
	}
	else
	{
		cerr << "Could not open file " << endl;
		return 1;
	}

	while( x < d.size() )	// Check for duplicates in the file
	{
		unsigned int y = 0;
		while(y < d.size())
		{
			if(y == x)
			{
				y++;
			}
			if(d[x] == d[y])
			{
				d.erase(d.begin()+x);
			}
			y++;
		}
		x++;
	}


	for(unsigned int i = 0; i < d.size(); i++)	// Changes index to account for duplicates that have been deleted
	{
		stringstream ss;
		ss << (i + 1);
		d[i].setIndex(ss.str());
	}

	if(outFile.is_open())
	{
		for(unsigned int i = 0; i < d.size(); i++)	// Puts all data into output file
		{
			outFile << d[i];
		}
		outFile.close();
	}

	//	Testing
	cout << "Testing formatted data: " << endl;	// Testing to make sure output is correct

	for(unsigned int i = 0; i < d.size(); i++)
	{
		cout << d[i];
	}

	cout << "Testing getters: " << endl;	// Testing getters

	cout << d[15].getIndex() << endl;
	cout << d[15].getFName() << endl;
	cout << d[15].getLName() << endl;
	cout << d[15].getAddress() << endl;
	cout << d[15].getCity() << endl;
	cout << d[15].getState() << endl;
	cout << d[15].getZip() << endl;

	cout << modFileName << endl;	// Testing modded file name

	return 0;
}
