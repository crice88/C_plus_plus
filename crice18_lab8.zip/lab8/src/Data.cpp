/*
 * Data.cpp
 *
 *  Created on: Mar 23, 2015
 *      Author: student
 */

#include "Data.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

// Getters
const string Data::getIndex()
{
	return index;
}
const string Data::getFName()
{
	return fname;
}
const string Data::getLName()
{
	return lname;
}
const string Data::getAddress()
{
	return address;
}
const string Data::getCity()
{
	return city;
}
const string Data::getState()
{
	return state;
}
const string Data::getZip()
{
	return zip;
}

// Setter
void Data::setIndex(string x)
{
	index = x;
}

Data::Data()	// Default constructor
{
	index = "";
	fname = "";
	lname = "";
	address = "";
	city = "";
	state = "";
	zip = "";
}

Data::Data(string s)	// Requires string
{
	stringstream ss(s);

	getline(ss, index, ',');	// Extract values and store them in appropriate objects
	getline(ss, fname, ',');
	getline(ss, lname, ',');
	getline(ss, address, ',');
	getline(ss, city, ',');
	getline(ss, state, ',');
	getline(ss, zip, ',');

}

bool operator==(const Data dlh, const Data drh)	// Check for equality (Overrides ==)
{
	if( (dlh.index == drh.index) || ((dlh.fname == drh.fname) && (dlh.lname == drh.lname) && (dlh.address == drh.address) &&
		(dlh.city == drh.city)	&& (dlh.state == drh.state) && (dlh.zip == drh.zip)))
		return true;
	else
		return false;
}

ostream& operator <<(std::ostream& ss, const Data& d)	// Outputs formatted data
{
	//ss << "Index: " << d.index << " First Name: " << d.fname << " Last Name: " << d.lname << endl << "Address: " << d.address
	   //<< " City: " << d.city << " State: " << d.state << " Zip: " << d.zip << endl;
	ss << d.index << "," << d.fname << "," << d.lname << "," << d.address << "," <<
			d.city << "," << d.state << "," << d.zip << endl;

	return ss;
}

Data::~Data()
{
	// TODO Auto-generated destructor stub
}

