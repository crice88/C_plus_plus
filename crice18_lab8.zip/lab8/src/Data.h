/*
 * Data.h
 *
 *  Created on: Mar 23, 2015
 *      Author: student
 */
#include <iostream>
#include <fstream>
#include <string>

#ifndef DATA_H_
#define DATA_H_

using namespace std;

class Data
{
public:
	Data(string s);
	Data();

	friend bool operator==(Data dlh, Data drh);
	friend ostream& operator <<(std::ostream&, const Data&);

	const string getIndex();
	const string getFName();
	const string getLName();
	const string getAddress();
	const string getCity();
	const string getState();
	const string getZip();

	void setIndex(string x);

	virtual ~Data();
private:
	string index;
	string fname;
	string lname;
	string address;
	string city;
	string state;
	string zip;
};

#endif /* DATA_H_ */
