//============================================================================
// Name        : lab8.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "Data.h"

using namespace std;

void error(string s)
{
	throw s;
}

int main()
{
	vector<string> s;
	vector<Data> d;
	string test;
	ifstream inFile("/home/student/Dropbox/C++/resources/database.csv");
	if(!inFile) error("nope");

	while(!inFile.eof())
	{
		string data;
		inFile >> data;
		s.push_back(data);
	}

	for(unsigned int i = 0; i < s.size(); i++)
	{
		string test = s[i];
		d[i] = Data(test);
	}

	return 0;
}
