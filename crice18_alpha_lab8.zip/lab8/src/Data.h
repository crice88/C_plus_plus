/*
 * Data.h
 *
 *  Created on: Mar 23, 2015
 *      Author: student
 */
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>

#ifndef DATA_H_
#define DATA_H_

using namespace std;

class Data
{
public:
	Data();
	Data(string s);
	virtual ~Data();

	string getIndex();
	string getFName();
	string getLName();
	string getAddress();
	string getCity();
	string getState();
	string getZip();
private:

	string index;
	string fname;
	string lname;
	string address;
	string city;
	string state;
	string zip;
};

#endif /* DATA_H_ */
