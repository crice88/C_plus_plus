/*
 * Data.cpp
 *
 *  Created on: Mar 23, 2015
 *      Author: student
 */

#include "Data.h"
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

string Data::getIndex()
{
	return index;
}
string Data::getFName()
{
	return fname;
}
string Data::getLName()
{
	return lname;
}
string Data::getAddress()
{
	return address;
}
string Data::getCity()
{
	return city;
}
string Data::getState()
{
	return state;
}
string Data::getZip()
{
	return zip;
}

Data::Data()
{

}

Data::Data(string s)
{
	vector<string> data;
	stringstream ss(s);
	cout << ss;
	string parse;

	while(ss >> parse)
	{
		data.push_back(parse);
		if(ss.peek() == ',')
		{
			ss.ignore();
		}
	}

	string index = data[0];
	string fname = data[1];
	string lname = data[2];
	string address = data[3];
	string city = data[4];
	string state = data[5];
	string zip = data[6];
}

Data::~Data()
{
	// TODO Auto-generated destructor stub
}

