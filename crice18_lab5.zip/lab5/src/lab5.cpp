//============================================================================
// Name        : lab5.cpp
// Author      : Colin Rice
// Version     :
// Description : Lab 5, operator overloading
//============================================================================

#include <iostream>
#include <sstream>
#include "Time.h"

using namespace std;
int main()
{
	cout << "***Now testing the overloaded operators***" << endl;
	cout << "***Testing addition***" << endl;	// Testing the addition properties
	Time t1(1);
	Time t2(2);
	cout << "Starting value: " << t1 << endl;
	cout << "Starting value: " << t2 << endl;
	Time t3 = t1 + t2;
	cout << "Ending Value: " << t3.toString() << "\n" << endl;

	cout << "***Testing subtraction***" << endl;	// Testing the subtraction properties
	Time t4(16);
	Time t5(19);
	cout << "Starting value: " << t5 << endl;
	cout << "Starting value: " << t4 << endl;
	Time t6 = t5 - t4;
	cout << "Ending Value: " << t3.toString() << "\n" << endl;

	cout << "***Testing ostream***" << endl;	// Testing the << operator
	ostringstream s1;
	Time t7(15, 0, 16, 32);
	cout << "Starting value: " << t7 << endl;
	s1 << t7;
	cout << "Ending Value: " << s1.str();

	cout << "***Testing < (true)***" << endl;	// Testing the < operator, true
	Time t8(10000);
	Time t9( 4, 35, 45, 465);
	cout << "Starting value: " << t8 << endl;
	cout << "Starting value: " << t9 << endl;
	cout << "Ending Value: " << ( t8 < t9 ) << "\n" << endl;

	cout << "***Testing < (false)***" << endl;	// Testing the < operator, false
	cout << "Starting value: " << t9 << endl;
	cout << "Starting value: " << t8 << endl;
	cout << "Ending Value: " << ( t9 < t8 ) << "\n" <<endl;

	cout << "***Testing == (true)***" << endl;	// Testing the == operator, true
	Time t10(15000);
	Time t11(15000);
	cout << "Starting value: " << t10 << endl;
	cout << "Starting value: " << t11 << endl;
	cout << "Ending Value: " << ( t10 == t11) << "\n" << endl;

	cout << "***Testing == (false)***" << endl;	// Testing the == operator, false
	cout << "Starting value: " << t9 << endl;
	cout << "Starting value: " << t10 << endl;
	cout << "Ending Value: " << (t9 == t10) << "\n" << endl;

	cout << "***Testing wrap-around with addition***" << endl;	// Wrap-around addition
	Time t12(13, 40, 59, 900 );
	Time t13(10, 22, 14, 504);
	cout << "Starting value: " << t12 << endl;
	cout << "Starting value: " << t13 << endl;
	Time t14 = t12 + t13;
	cout << "Ending Value: " << t14 << endl;

	cout << "***Testing wrap-around with subtraction***" << endl;	// Wrap-around subtraction
	Time t15(3, 10, 10,20);
	Time t16(13, 20, 12, 30);
	cout << "Starting value: " << t15 << endl;
	cout << "Starting value: " << t16 << endl;
	Time t17 = t15 - t16;
	cout << "Ending Value: " << t17 << endl;

	// Basic functions test
	Time t18(13, 45, 52, 125);

	cout << "***Now testing the basic functionality***" << endl;
	cout << "Time as long: " << t18.asLong() << endl;	// Check asLong
	t18.set24Hour(false);
	cout << "Time 24 hour flag: "  <<  t18.is24Hour() << endl;
	cout << "Time as 12 hour: " << t18.toString() << endl;
	t18.set24Hour(true);
	cout << "Time 24 hour flag: "  <<  t18.is24Hour() << endl;
	cout << "Time as 24 hour: " << t18.toString() << "\n" << endl;

	Time t19(13, 45, 52, 125);
	Time t20;
	Time t21(14457600);

	cout << "Starting Value: " << t19 << endl;
	cout << "Time as long: " << t19.asLong() << endl;	// Check 24 hour flag and toString
	cout <<  "24 Hour Flag: " << t19.is24Hour()<< endl;
	t19.set24Hour(false);
	cout << "24 Hour Flag set to false: " << t19.toString() << "\n" << endl;

	cout << "Starting Value: " << t20 << endl;
	cout << "Time as long: " << t20.asLong() << endl;
	cout <<  "24 Hour Flag: " << t20.is24Hour()<< endl;
	t20.set24Hour(false);
	cout << "24 Hour Flag set to false: " << t20.toString() << "\n" << endl;

	cout << "Starting Value: " << t21 << endl;
	cout << "Time as long: " << t21.asLong() << endl;
	cout <<  "24 Hour Flag: " << t21.is24Hour()<< endl;
	t21.set24Hour(false);
	cout << "24 Hour Flag set to false: " << t21.toString() << "\n"<< endl;

	return 0;
}
