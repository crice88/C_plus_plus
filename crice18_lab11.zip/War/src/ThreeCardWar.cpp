//============================================================================
// Name        : ThreeCardWar.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <sstream>

#include "Deck.h"
#include "Card.h"

using namespace std;

int main()
{
	Deck d;
	Deck d1;
	d.shuffle();
	Card c = d.draw();
	Card c1(Card::Spades, Card::Four);
	Card c2(Card::Hearts, Card::King);
	Card c3(Card::Spades, Card::Four);
	Card c4 = Card::getJoker();
	Card c5 = d1.draw();
	Card c6 = d1.draw();
	Card c7 = d1.draw();

	cout << (c1 == c3) << endl;	// Testing equality operator
	cout << (c1 == c2) << endl;
	cout << (c1 < c2) << endl;	// Testing less than operator
	cout << (c2 < c1) << endl;
	cout << (d.isEmpty()) << endl;	// Testing the isEmpty function
	cout << c4 << endl;	// Testing getJoker()
	cout << c3 << endl;	// Testing basic constructor functionality
	cout << c2 << endl;
	cout << c4.isJoker() << endl;	// Testing isJoker()
	cout << c << endl;	// Testing shuffle()
	cout << c5 << endl;	// Testing draw() and to make sure the elements are created in correct order
	cout << c6 << endl;
	cout << c7 << endl;

	return 0;
}
