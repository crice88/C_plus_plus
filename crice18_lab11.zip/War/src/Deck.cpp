/*
 * Deck.cpp
 *
 *  Created on: Nov 11, 2014
 *      Author: williamhooper
 */

#include "Deck.h"
#include "Card.h"
#include <iostream>
#include <string>
#include <algorithm>
#include <stdexcept>

Deck::Deck() : nextCard(0)	// nextCard used as a counter to know how many cards are in the deck (0 = full deck)
{
	int suitIterator = 0;
	while(suitIterator < 4)	// Starts at the first suit and adds each rank of that suit to the deck
	{
		for(int rankIterator = 1; rankIterator < 14; rankIterator++)	// Iterates through all ranks
		{
			cardDeck.push_back(Card(Card::Suit(suitIterator), Card::Rank(rankIterator)));
		}
		suitIterator++;
	}
}

void Deck::shuffle()	// Uses algorithm to perform a random shuffle of the elements in the vector
{
	std::random_shuffle (cardDeck.begin(), cardDeck.end());
}

bool Deck::isEmpty() const	// Checks to see if the deck is empty (52 = empty desk)
{
	return (nextCard == 52);
}

const Card Deck::draw()	// Returns next available card in the vector
{
	Card c = cardDeck[nextCard];
	nextCard++;
	return c;
}

Deck::~Deck()
{

}

