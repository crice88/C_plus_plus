/*
 * Time.cpp
 *
 *  Created on: Feb 15, 2015
 *      Author: Colin Rice
 *      Class: CSCI 66
 *      Lab 4
 */

#include "Time.h"
#include <stdexcept>
#include <sstream>

Time::Time(int h, int m, int s, int ms) // Takes input as int, stores individual vales as int
{
	if( h > 23 || h < 1) error("Bad Input!");	// Checking boundaries
	if( m > 59 || m < 0 ) error("Bad Input!");
	if(s > 59 || s < 0) error("Bad Input!");
	if(ms > 999 || ms < 0) error("Bad Input!");
	if(h > 12)
		PMflag = true;

	hours = h;
	minutes = m;
	seconds = s;
	milliseconds = ms;
}

Time::Time(long time)	// Accepts time as long and sets variables accordingly
{
	individualValues(time);
}

Time::Time() // Sets default time
{
	hours = 4;
	minutes = 00;
	seconds = 00;
	milliseconds = 00;
	PMflag = false;
}

void Time::individualValues(long time)	// Code segment credit to Bill Hooper
{
	if (time > 99999999 || time < 0) error("Bad Input!");	// More boundary checking

	milliseconds = time % 1000;
	if(milliseconds > 999 || milliseconds < 0) error("Bad Input!");
	time /= 1000;

	seconds = time % 60;
	if(seconds > 59 || seconds < 0) error("Bad Input!");
	time /= 60;

	minutes = time % 60;
	if( minutes > 59 || minutes < 0 ) error("Bad Input!");
	time /= 60;

	hours = time;
	if( hours > 24 || hours < 1 ) error("Bad Input!");
	if ( hours > 12)
		PMflag = true;
}

long Time::asLong() const	// Code segment credit to Bill Hooper
{
	long longValue;

	longValue = (long) hours;
	longValue = (longValue * 60) + minutes;
	longValue = (longValue * 60) + seconds;
	longValue = (longValue * 1000) + milliseconds;
	return longValue;
}

string Time::toString() const	// Creates a string with h, m, s, and ms, displays to console
{
	ostringstream s1;
	string timeOfDay;

	if(is24Hour() == true || PMflag == true)
		timeOfDay = "PM";
	else
		timeOfDay = "AM";
	s1 << hours << ":" << minutes << ":" << seconds << ":" << milliseconds << " " << timeOfDay;
	return s1.str();
}

void Time::set24Hour(bool value)	// If false, time is in standard 12-hour format, PMflag set
{
	if( value == false )
	{
		if(hours > 12)
		{
			hours -= 12;
			PMflag = true;
		}
	}
	if( value == true )
	{
		if( hours < 12 && PMflag == true)
			hours += 12;
	}

}

bool Time::is24Hour() const	// Checks to see if time is in 24-hour format, or standard 12-hour
{
	if( hours > 12)
		return true;
	else
		return false;
}



void Time::error(string s)	// Throws an error, and does not modify values
{
	cerr << s;
	throw runtime_error(s);
}


Time::~Time() {
	// TODO Auto-generated destructor stub
}

