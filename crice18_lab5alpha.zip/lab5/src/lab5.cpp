//============================================================================
// Name        : lab5.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "Time.h"

using namespace std;
int main()
{
	Time t1();
	Time t2();

	cout <<


	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	return 0;
}
